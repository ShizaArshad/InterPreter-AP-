import scala.io.Source
import java.io.File
object Token {
  def main(arg:Array[String])=
  {
    fileread()
  }
  def fileread()
  {
    val filename="file.app"
  Source.fromFile(filename).foreach{
  print}
  }
  
  
}